"""Independent GLB and actual geometry render checks; no Factorio integration."""
from pathlib import Path
import hashlib, json
import trimesh as t
import numpy as np
from PIL import Image
P=Path(__file__).resolve().parent; p=P/'output'; q=json.loads((p/'qa.json').read_text());result={};T=t.transformations.rotation_matrix(-np.pi/2,[1,0,0]);original=t.load(P.parent/'Locomotive_v3_body.glb',force='scene',process=False)
for name,rec in q.items():
 s=t.load(p/(name+'.glb'),force='scene',process=False);nonclosed=[];badwind=[];new=0;maxpivot=0.;maxsource=0.
 assert hashlib.sha256((p/(name+'.glb')).read_bytes()).hexdigest()==rec['sha256']
 for n in s.graph.nodes_geometry:
  mat,key=s.graph[n];m=s.geometry[key];assert np.isfinite(m.vertices).all() and (m.area_faces>1e-12).all()
  if n in rec['source_node_mapping']:
   sm,sk=original.graph[n];a=t.transform_points(original.geometry[sk].vertices,sm);b=t.transform_points(m.vertices,mat);r=rec['source_node_mapping'][n];expected=a+(T@np.r_[r['translation_BU'],0])[:3];assert np.array_equal(original.geometry[sk].faces,m.faces);maxsource=max(maxsource,float(np.max(abs(b-expected))));continue
  new+=1;m2=t.Trimesh(vertices=m.vertices,faces=m.faces,process=True);m2.merge_vertices(merge_tex=True,merge_norm=True)
  if not m2.is_watertight:nonclosed.append(n)
  if not m2.is_winding_consistent:badwind.append(n)
  g=rec['part_groups'][n]
  if g in rec['moving_groups']:
   expected=(T@np.r_[rec['moving_groups'][g]['pivot_BU'],1])[:3];maxpivot=max(maxpivot,float(np.max(abs(mat[:3,3]-expected))))
 assert not nonclosed and not badwind and maxpivot<2e-6 and maxsource<2e-6
 assert rec['bogie_nodes']==186
 assert len(rec['moving_groups'])=={'cargo':9,'tank':0,'battery':4}[name]
 result[name]={'new_meshes_checked':new,'nonclosed':nonclosed,'inconsistent_winding':badwind,'finite_positive_area_after_reload':True,'moving_groups':len(rec['moving_groups']),'triangles':rec['triangles'],'bogie_nodes':rec['bogie_nodes'],'sha256':rec['sha256'],'bounds_gltf':rec['bounds_gltf'],'max_pivot_error_BU':maxpivot,'max_source_error_BU':maxsource}
for a,b in [('cargo_hero.png','cargo_open_hero.png'),('battery_top.png','battery_rotated_top.png')]:
 aa=np.array(Image.open(p/a));bb=np.array(Image.open(p/b));pct=float(np.any(aa!=bb,axis=-1).mean()*100);assert pct>.05;result[a]={'changed_pixel_percent':pct,'note':'actual geometry changed in render; not runtime animation'}
(p/'independent_qa.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2));print('INDEPENDENT GLB CHECK PASS')
