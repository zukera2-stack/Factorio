"""A3DS method B: editable V3 mechanical assembly, owner-approved wagon concept.
Original V3 generator helpers imported verbatim (definitions only); no original asset overwritten.
Coordinates X across, +Y front, Z up; exported GLB Y-up. Model units inferred from V3.
"""
from pathlib import Path
import math, json, hashlib, re, sys
import numpy as np
import trimesh as tm
from PIL import Image, ImageDraw
from shapely.geometry import Polygon
from shapely.ops import triangulate
import vtk
from vtk.util.numpy_support import numpy_to_vtk,numpy_to_vtkIdTypeArray
P=Path(__file__).resolve().parent
O=P/'output'; O.mkdir(exist_ok=True)
# Reuse the exact A3DS V3 method B primitive builders and palette.
source=(P/'v3_original_build.py').read_text(); exec(source.split('# X width, +Y nose, Z up.')[0]); P=Path(__file__).resolve().parent; O=P/'output'
source_glb=P.parent/'Locomotive_v3_body.glb'
assert hashlib.sha256(source_glb.read_bytes()).hexdigest()=='6970a44dffaae84001b7c08bebac80083933982895461bb8f0b0c913bc566955'
original=tm.load(source_glb,force='scene',process=False)
T=tm.transformations.rotation_matrix(-math.pi/2,[1,0,0]); Ti=np.linalg.inv(T)
C.update({'yellow':(231,175,40),'fan':(83,87,92),'interior':(39,42,45),'grille':(137,141,144)})
for k in ['yellow','fan','interior','grille']: M[k]=PBRMaterial(name=k,baseColorFactor=[*C[k],255],metallicFactor=.25,roughnessFactor=.5)
params={'body_half_length':3.70,'straight_half_length':3.27,'body_half_width':.8448,'roof_half_width':.68,'roof_z':2.255,'side_z_bottom':.715,'side_z_top':1.94,'bogie_centers':[-2.34,2.34],'roof_hatch_centers':[-2.05,0,2.05],'side_hatch_centers':[-2.05,0,2.05],'tank_valve_centers':[-2.10,0,2.10],'battery_module_centers':[-2.40,-.80,.80,2.40],'scale_note':'V3 artistic model units, not meters or certified Factorio calibration'}
(P/'parameters.json').write_text(json.dumps(params,indent=2))
qa={}; current=''; pivots={}; used={}; shell_stats={}
def paint_material():
    # Stripe is painted texture (not geometry). U=longitudinal, V=height.
    a=np.full((512,512,3),C['silver'],np.uint8); zz=np.linspace(2.26,.65,512); a[(zz>=.735)&(zz<=.90),:]=C['red']; a[zz<.735,:]=C['dark']; a[zz>1.94,:]=C['roof']; return Image.fromarray(a)
tex=paint_material(); tex.save(O/'v3_wagon_livery.png'); livery=PBRMaterial(name='V3 wagon painted livery',baseColorTexture=tex,baseColorFactor=[255]*4,metallicFactor=.32,roughnessFactor=.45)
def applypaint(m):
    v=m.vertices; m.visual=TextureVisuals(uv=np.column_stack(((v[:,1]+3.7)/7.4,(v[:,2]-.65)/1.61)),material=livery); return m

def poly_extrusion(poly,thick,xf):
    """Closed panel with true polygon holes; area check prevents silent dropped triangles."""
    tris=[p for p in triangulate(poly) if poly.covers(p)]
    area=sum(p.area for p in tris); assert abs(area-poly.area)<1e-8,(area,poly.area)
    v=[]; f=[]
    for t in tris:
        q=np.array(t.exterior.coords[:3]);
        if np.linalg.det(np.stack([q[1]-q[0],q[2]-q[0]]))<0:q=q[::-1]
        k=len(v);v.extend([xf(*p,0) for p in q]+[xf(*p,thick) for p in q]);f.extend([[k,k+2,k+1],[k+3,k+4,k+5]])
    for ring in [poly.exterior,*poly.interiors]:
        pts=list(ring.coords)
        for a,b in zip(pts[:-1],pts[1:]):
            k=len(v);v.extend([xf(*a,0),xf(*b,0),xf(*b,thick),xf(*a,thick)]);f.extend([[k,k+1,k+2],[k,k+2,k+3]])
    m=tm.Trimesh(v,f,process=True);m.fix_normals(); assert m.is_watertight, 'panel not watertight';return m

def ell(cu,cv,ru,rv,n=72):
    return [(cu+ru*math.cos(t),cv+rv*math.sin(t)) for t in np.linspace(0,2*math.pi,n,endpoint=False)]
def rectangle(a,b,c,d):return [(a,c),(b,c),(b,d),(a,d)]
def panel(name,poly,thick,xf,col,group='body'):
    m=poly_extrusion(poly,thick,xf); return add(name,m,applypaint(m).visual if col=='paint' else col,group)

def copy_v3():
    for n in sorted(original.graph.nodes_geometry):
        k=0 if n.startswith(('bogie0_','b0_w')) else 1 if n.startswith(('bogie1_','b1_w')) else None
        keep=k is not None or n=='underframe' or n.startswith(('front_buffer','rear_buffer','front_coupler','rear_coupler')) or re.search(r'_(underbox|cabinetbolt|cabinet_latch)',n)
        if not keep:continue
        mat,key=original.graph[n]; src=original.geometry[key]; m=src.copy(); m.apply_transform(Ti@mat); dy=(.04 if k==0 else .04) if k is not None else ( -.09 if n.startswith('front_coupler') else -.09 if n.startswith('rear_coupler') else 0)
        # Original positive center=+2.30, negative=-2.38: both translate +.04.
        m.apply_translation([0,dy,0]);
        parts.append((n,m,None, f'V3_bogie{k}' if k is not None else 'V3_chassis'));used[n]={'original_node':n,'translation_BU':[0,dy,0],'bogie':k,'source_vertices':len(src.vertices),'source_triangles':len(src.faces)}

def loft(name,sections,contour,col,group='body'):
    v=[];f=[];n=len(contour)
    for y,w,bot,top in sections:
        v.extend([(x*w,y,bot+h*(top-bot)) for x,h in contour])
    for i in range(len(sections)-1):
        for j in range(n):
            k=(j+1)%n; a=i*n+j;b=i*n+k;c=(i+1)*n+j;d=(i+1)*n+k;f.extend([(a,b,c),(b,d,c)])
    for i in [0,len(sections)-1]:
        y,w,bot,top=sections[i];k=len(v);v.append([0,y,(bot+top)/2]);f.extend([(k,i*n+j,i*n+(j+1)%n) for j in range(n)])
    m=tm.Trimesh(v,f,process=True);m.fix_normals();assert m.is_watertight;return add(name,m,col,group)

Q=[(-1,0),(-1,(1.94-.715)/(2.255-.715)),(-.68/.8448,1),(.68/.8448,1),(1,(1.94-.715)/(2.255-.715)),(1,0)]
def common_hull(cargo):
    L=params['straight_half_length']; zb=.715; zt=1.94; zroof=2.255; x=.8448; xr=.68
    # Separate sloping graphite end shells, shared shape family, no cab.
    for s in [-1,1]:
        end=loft(f'end_shell_{s}',[(s*L,x,zb,zroof),(s*3.41,.84,.715,2.235),(s*3.52,.80,.72,2.15),(s*3.61,.75,.73,2.04),(s*3.68,.67,.74,1.90),(s*3.70,.63,.75,1.80)],Q,'dark'); a=np.full((512,16,3),C['dark'],np.uint8); zz=np.linspace(2.26,.65,512); a[(zz>=.735)&(zz<=.90),:]=C['red']; et=Image.fromarray(a); em=PBRMaterial(name='Graphite end painted stripe',baseColorTexture=et,baseColorFactor=[255]*4,metallicFactor=.32,roughnessFactor=.45); end.visual=TextureVisuals(uv=np.column_stack((np.full(len(end.vertices),.5),(end.vertices[:,2]-.65)/1.61)),material=em)
        for xx in [-.48,.48]:box(f'end_marker_{s}_{xx}',(xx,s*3.703,.96),(.13,.04,.22),'steel',.012)
    # actual roof and side apertures, rather than lids over solid walls
    for s in [-1,1]:
        holes=[ell(y,1.40,.77,.34) for y in params['side_hatch_centers']] if cargo else []
        poly=Polygon(rectangle(-L,L,zb,zt),holes)
        panel(f'side_shell_{s}',poly,.045,lambda y,z,d:(s*(x-d),y,z),'paint')
        # chamfered shoulder extends from side to flat roof
        panel(f'roof_shoulder_{s}',Polygon([(s*x,zt),(s*xr,zroof),(s*(xr-.025),zroof-.045),(s*(x-.045),zt)]),2*L,lambda xx,z,d:(xx,-L+d,z),'dark')
        # painted end lower band continuation, flush material patch in dark cap region, no raised stripe
    roofholes=[ell(0,y,.43,.70) for y in params['roof_hatch_centers']] if cargo else []
    panel('roof_shell',Polygon(rectangle(-xr,xr,-L,L),roofholes),.045,lambda x,y,d:(x,y,zroof-d),'roof')
    box('internal_floor',(0,0,.76),(1.54,6.52,.11),'interior',.018)
    # seam, functional edge details
    for s in [-1,1]:
        for yy in [-3.02,-1.03,1.03,3.02]:
            box(f'panel_joint_{s}_{yy}',(s*.847,yy,1.40),(.008,.015,1.03),'seam',.002)
            for zz in [1.01,1.86]:cyl(f'side_fastener_{s}_{yy}_{zz}',(s*.852,yy,zz),.018,.012,'steel',(1,0,0),12)

def cargo_body():
    common_hull(True)
    for i,y in enumerate(params['roof_hatch_centers']):
        g=f'roof_hatch_{i}'; pivots[g]={'axis':[0,1,0],'pivot_BU':[-.475,y,2.29],'open_deg':-100,'kind':'hinge'}
        rim=Polygon(ell(0,y,.49,.78),[ell(0,y,.43,.70)])
        panel(g+'_rim',rim,.035,lambda x,y,d:(x,y,2.255+d),'black')
        panel(g+'_lid',Polygon(ell(0,y,.468,.748)),.065,lambda x,y,d:(x,y,2.286+d),'steel',g)
        for dy in [-.36,.36]:box(g+f'_hinge_{dy}',(-.47,y+dy,2.31),(.105,.18,.075),'dark',.012)
        box(g+'_handle',(.29,y,2.372),(.15,.23,.04),'black',.012,g)
    for s in [-1,1]:
        for i,y in enumerate(params['side_hatch_centers']):
            g=f'side_hatch_{s}_{i}';pivots[g]={'axis':[0,1,0],'pivot_BU':[s*.88,y,1.78],'open_deg':-s*100,'kind':'hinge'}
            rim=Polygon(ell(y,1.40,.83,.395),[ell(y,1.40,.77,.34)])
            panel(g+'_rim',rim,.024,lambda y,z,d:(s*(.845+d),y,z),'seam')
            panel(g+'_lid',Polygon(ell(y,1.40,.805,.374)),.034,lambda y,z,d:(s*(.869+d),y,z),'silver',g)
            for dy in [-.37,.37]:box(g+f'_hinge_{dy}',(s*.902,y+dy,1.77),(.06,.13,.08),'steel',.012)
            box(g+'_handle',(s*.922,y,1.12),(.055,.24,.055),'dark',.015,g)
    for y in [-1.025,1.025]:box(f'cargo_internal_partition_{y}',(0,y,1.20),(1.48,.06,.88),'interior',.015)

def tank_body():
    # Single uninterrupted closed elliptical vessel, rounded ends, 3 valve stations.
    # X max .82, z range .77..2.29. Subtle dark end finish is painted, not separate tanks.
    rings=[]
    for y in [-3.70,-3.68,-3.63,-3.55,-3.44,-3.30,-3.15,0,3.15,3.30,3.44,3.55,3.63,3.68,3.70]:
        r=float(np.interp(abs(y),[0,3.15,3.30,3.44,3.55,3.63,3.68,3.70],[1,1,.995,.98,.95,.90,.82,.73]));rings.append((y,.8448*r,1.52-.76*r,1.52+.76*r))
    q=[(math.cos(t),(math.sin(t)+1)/2) for t in np.linspace(0,2*math.pi,96,endpoint=False)];m=loft('continuous_tank',rings,q,'silver')
    # UV longitudinal dark end paint on one continuous tank shell
    a=np.full((256,1024,3),C['silver'],np.uint8);Y=np.linspace(-3.70,3.70,1024);a[:,abs(Y)>3.17]=C['dark'];tanktex=Image.fromarray(a);tanktex.save(O/'tank_livery.png');mat=PBRMaterial(name='tank continuous painted shell',baseColorTexture=tanktex,baseColorFactor=[255]*4,metallicFactor=.45,roughnessFactor=.45);m.visual=TextureVisuals(uv=np.column_stack(((m.vertices[:,1]+3.70)/7.4,np.full(len(m.vertices),.5))),material=mat)
    # Painted chassis side sill. Same palette, no separate tank partitions.
    for s in [-1,1]:
        sill=box(f'painted_sill_{s}',(s*.73,0,.79),(.22,7.35,.20),'frame',.024);applypaint(sill)
    for y in [-2.30,2.30]:
        for s in [-1,1]:box(f'tank_support_{s}_{y}',(s*.59,y,.85),(.25,.36,.25),'steel',.045)
    for i,y in enumerate(params['tank_valve_centers']):
        g=f'valve_{i}';cyl(g+'_base',(0,y,2.29),.225,.11,'dark',N=32);cyl(g+'_flange',(0,y,2.37),.19,.075,'steel');cyl(g+'_stem',(0,y,2.48),.078,.18,'steel');cyl(g+'_hub',(0,y,2.58),.068,.055,'red')
        for j in range(8):
            a=j*math.tau/8;cyl(g+f'_bolt{j}',(.16*math.cos(a),y+.16*math.sin(a),2.422),.023,.024,'steel',N=12)
        for j in range(4):
            a=j*math.tau/4;rod(g+f'_spoke{j}',(0,y,2.60),(.16*math.cos(a),y+.16*math.sin(a),2.60),.015,'red')
        # closed ring, actual open valve wheel
        ring=Polygon(ell(0,y,.19,.19,48),[ell(0,y,.157,.157,48)]);panel(g+'_handwheel',ring,.026,lambda x,y,d:(x,y,2.59+d),'red')

def bolt_square(g,y,z):
    for x in [-.59,.59]:
        for dy in [-.59,.59]:cyl(g+f'_bolt_{x}_{dy}',(x,y+dy,z),.033,.022,'steel',N=12)
def fan_blade(g,y,k,z):
    # broad curved blade with finite thickness; each independently named, common rotor pivot
    a=k*math.tau/7; rad=[(.12,-.06),(.26,-.11),(.45,-.08),(.52,.05),(.47,.135),(.29,.12),(.13,.07)]
    q=[(r*math.cos(a)-t*math.sin(a),y+r*math.sin(a)+t*math.cos(a)) for r,t in rad];panel(g+f'_blade_{k}',Polygon(q),.028,lambda x,y,d:(x,y,z+d),'fan',g)

def battery_body():
    common_hull(False)
    for i,y in enumerate(params['battery_module_centers']):
        g=f'fan_{i}';pivots[g]={'axis':[0,0,1],'pivot_BU':[0,y,2.48],'kind':'rotor','activation':'connected locomotive AND actual available current (not implemented)'}
        box(f'battery_module_{i}_base',(0,y,2.30),(1.37,1.37,.16),'dark',.045)
        # square housing with actual side openings/grid texture simulated by metal bars, dark core beneath
        box(f'battery_module_{i}_core',(0,y,2.43),(1.18,1.18,.16),'black',.025)
        for s in [-1,1]:
            for dy in np.linspace(-.48,.48,13):box(f'module_{i}_sidegrille_{s}_{dy:.3f}',(s*.644,y+dy,2.43),(.05,.024,.145),'grille',.004)
            for xx in np.linspace(-.48,.48,13):box(f'module_{i}_endgrille_{s}_{xx:.3f}',(xx,y+s*.644,2.43),(.024,.05,.145),'grille',.004)
        for s in [-1,1]:
            for z in [2.41,2.47]:
                box(f'module_{i}_side_grille_cross_{s}_{z}',(s*.675,y,z),(.018,1.03,.015),'grille',.002);box(f'module_{i}_end_grille_cross_{s}_{z}',(0,y+s*.675,z),(1.03,.018,.015),'grille',.002)
        outer=rectangle(-.69,.69,y-.69,y+.69);hole=ell(0,y,.575,.575,96);panel(f'module_{i}_upper_frame',Polygon(outer,[hole]),.075,lambda x,y,d:(x,y,2.51+d),'steel');bolt_square(f'module_{i}',y,2.594)
        cyl(g+'_hub',(0,y,2.553),.12,.065,'rim',N=32,g=g)
        for k in range(7):fan_blade(g,y,k,2.53)
        # light open grille above rotor: two crossbars and thin concentric rings; no occluding solid disc
        for rr in [.24,.40,.55]:
            ring=Polygon(ell(0,y,rr,rr,64),[ell(0,y,rr-.012,rr-.012,64)]);panel(f'module_{i}_guard_ring_{rr}',ring,.014,lambda x,y,d:(x,y,2.604+d),'grille')
        for a in [0,math.pi/2]:rod(f'module_{i}_guard_cross_{a}',(-.55*math.cos(a),y-.55*math.sin(a),2.612),(.55*math.cos(a),y+.55*math.sin(a),2.612),.012,'grille')
    for s in [-1,1]:
        for y in [-2.4,2.4]:
            box(f'power_vent_{s}_{y}',(s*.859,y,1.48),(.055,.48,.42),'black',.025)
            for z in np.linspace(1.33,1.63,6):box(f'power_vent_slats_{s}_{y}_{z}',(s*.897,y,z),(.035,.43,.033),'steel',.006)
        box(f'power_panel_{s}',(s*.859,0,1.4),(.05,.85,.58),'seam',.02);box(f'power_panel_face_{s}',(s*.89,0,1.4),(.025,.80,.53),'silver',.012)
        bolt=[(-.08,.22),(.08,.22),(.015,.03),(.13,.03),(-.08,-.24),(-.035,-.035),(-.14,-.035)]
        panel(f'high_voltage_bolt_{s}',Polygon(bolt),.007,lambda y,z,d:(s*(.907+d),y,1.4+z),'yellow')

def render(parts,name,views):
    ren=vtk.vtkRenderer();ren.SetBackground(.91,.92,.935);ren.SetBackground2(.75,.78,.81);ren.GradientBackgroundOn();win=vtk.vtkRenderWindow();win.SetOffScreenRendering(1);win.SetMultiSamples(4);win.AddRenderer(ren)
    keep=[]
    for n,m,col,g in parts:
        pts=vtk.vtkPoints();pts.SetData(numpy_to_vtk(np.ascontiguousarray(m.vertices),deep=True));cells=vtk.vtkCellArray();ids=np.column_stack((np.full(len(m.faces),3),m.faces)).astype(np.int64);cells.SetCells(len(ids),numpy_to_vtkIdTypeArray(ids.ravel(),deep=True));poly=vtk.vtkPolyData();poly.SetPoints(pts);poly.SetPolys(cells)
        nn=numpy_to_vtk(np.asarray(m.vertex_normals,dtype=np.float32),deep=True);nn.SetNumberOfComponents(3);poly.GetPointData().SetNormals(nn)
        mapper=vtk.vtkPolyDataMapper();mapper.SetInputData(poly);act=vtk.vtkActor();act.SetMapper(mapper);pr=act.GetProperty();pr.SetInterpolationToPhong();pr.SetAmbient(.32);pr.SetDiffuse(.68);pr.SetSpecular(.22);pr.SetSpecularPower(24)
        material=getattr(m.visual,'material',None); im=getattr(material,'baseColorTexture',None); uv=getattr(m.visual,'uv',None)
        if im is not None and uv is not None:
            tc=numpy_to_vtk(np.asarray(uv,dtype=np.float32),deep=True);tc.SetNumberOfComponents(2);poly.GetPointData().SetTCoords(tc);a=np.array(im.convert('RGB'))[::-1].copy();vi=vtk.vtkImageData();vi.SetDimensions(a.shape[1],a.shape[0],1);vi.GetPointData().SetScalars(numpy_to_vtk(a.reshape(-1,3),deep=True,array_type=vtk.VTK_UNSIGNED_CHAR));tx=vtk.vtkTexture();tx.SetInputData(vi);tx.InterpolateOn();act.SetTexture(tx);pr.SetColor(1,1,1);keep.extend([vi,tx])
        else:
            color=np.array(col if col is not None else getattr(material,'baseColorFactor',[140,140,140,255]))[:3];pr.SetColor(*(color/(255 if color.max()>1 else 1)))
        ren.AddActor(act)
    ren.AutomaticLightCreationOff()
    for pos,intensity in [((-7,7,12),.9),((5,-6,7),.55),((2,6,3),.23)]:
        l=vtk.vtkLight();l.SetLightTypeToSceneLight();l.SetPosition(*pos);l.SetFocalPoint(0,0,1);l.SetIntensity(intensity);ren.AddLight(l)
    cam=ren.GetActiveCamera();cam.ParallelProjectionOn()
    for view,pos,up,scale,size in views:
        win.SetSize(*size);cam.SetPosition(*pos);cam.SetFocalPoint(0,0,1.35);cam.SetViewUp(*up);cam.SetParallelScale(scale);ren.ResetCameraClippingRange();win.Render();im=vtk.vtkWindowToImageFilter();im.SetInput(win);im.ReadFrontBufferOff();im.Update();wr=vtk.vtkPNGWriter();wr.SetFileName(str(O/f'{name}_{view}.png'));wr.SetInputConnection(im.GetOutputPort());wr.Write()
    win.Finalize()
# V3 exporter hard-edge normals, preserving actual source meshes.
exec(source[source.index('def with_normals(m,name):'):source.index('parts=[(name,with_normals')])
views=[('hero',(-11,9,7.5),(0,0,1),2.5,(1800,1000)),('side',(-15,0,1.35),(0,0,1),2.5,(1800,900)),('top',(0,0,20),(1,0,0),2.5,(1800,900)),('rear',(8,-11,6),(0,0,1),2.5,(1800,1000))]
for current,fn in [('cargo',cargo_body),('tank',tank_body),('battery',battery_body)]:
    parts.clear();pivots.clear();used.clear();copy_v3();fn(); parts[:]=[(n,m if n in used else with_normals(m,n),col,g) for n,m,col,g in parts]; sc=tm.Scene(); record={}
    for name,m,col,g in parts:
        # Use scene graph transform at actual local pivot for moving pieces. Individual parts retain stable coordinates.
        assert np.isfinite(m.vertices).all(); assert np.isfinite(m.vertex_normals).all(); assert np.all(m.area_faces>1e-12),(name,m.area_faces.min())
        mm=m.copy();pivot=np.array(pivots[g]['pivot_BU']) if g in pivots else np.zeros(3);mm.apply_translation(-pivot);mm.apply_transform(T);tf=np.eye(4);tf[:3,3]=(T@np.r_[pivot,1])[:3];sc.add_geometry(mm,geom_name=name,node_name=name,transform=tf);record[name]=g
    path=O/f'{current}.glb';path.write_bytes(sc.export(file_type='glb',include_normals=True));read=tm.load(path,force='scene',process=False);err=0
    for n,rec in used.items():
        om,ok=original.graph[n];nm,nk=read.graph[n];a=tm.transform_points(original.geometry[ok].vertices,om);b=tm.transform_points(read.geometry[nk].vertices,nm);expected=a+(T@np.r_[rec['translation_BU'],0])[:3];assert a.shape==b.shape;err=max(err,float(np.max(np.abs(b-expected))));assert np.array_equal(original.geometry[ok].faces,read.geometry[nk].faces),n
    assert err<2e-6,err
    assert len(read.geometry)==len(parts)
    qa[current]={'meshes':len(read.geometry),'triangles':sum(len(m.faces) for m in read.geometry.values()),'bounds_gltf':read.bounds.tolist(),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'original_v3_nodes_preserved':len(used),'bogie_nodes':sum(x['bogie'] is not None for x in used.values()),'max_original_vertex_translation_error_BU':err,'finite_vertices_normals_and_positive_triangle_areas':True,'all_panelextrusions_closed':True,'glb_readback':True,'moving_groups':dict(pivots),'part_groups':record,'source_node_mapping':dict(used),'limitations':['artistic reference, not calibrated','native Factorio pivot/scale, UV overlap and global intersections not certified','no native animation or sprites yet']}
    print(current,qa[current]['meshes'],qa[current]['triangles'],err,flush=True)
    render(parts,current,views)
    if current=='cargo':
        pp=[]
        for n,m,col,g in parts:
            m=m.copy()
            if g in pivots:
                p=pivots[g];m.apply_transform(tm.transformations.rotation_matrix(math.radians(p['open_deg']),p['axis'],p['pivot_BU']))
            pp.append((n,m,col,g))
        render(pp,'cargo_open',[views[0]])
    if current=='battery':
        pp=[]
        for n,m,col,g in parts:
            m=m.copy()
            if g in pivots: m.apply_transform(tm.transformations.rotation_matrix(math.radians(24),pivots[g]['axis'],pivots[g]['pivot_BU']))
            pp.append((n,m,col,g))
        render(pp,'battery_rotated',[views[2]])
    (O/'qa.json').write_text(json.dumps(qa,indent=2))
print('PASS: all three exported/read back; actual V3 bogie geometry verified',flush=True)
